const express=require('express')
const cors=require('cors')
const body=require('body-parser')
const app=express()
const pool = require("./pool");
console.log(cors);

const io = require("socket.io")(3030);
// 保存所有用户客户端的socket
let userOrder = {};
io.on("connection", (socket) => {
  userOrder[socket.id]=socket
  // 接收对应socket.id 的信息
  userOrder[socket.id].on("userpayment",res=>{
    let userArr=JSON.parse(res)
    userArr.forEach(e => {
      let sql = `insert into productsorder values(null,?,?,?,?,?,?,?,null)`;
      pool.query(sql,[e.seatnum,e.footname,e.state,e.taste,e.time,e.price,e.imgurl],(err,rs)=>{
        if(err) throw err;
        // 保存成功
        if (rs.affectedRows!==0) {
          io.emit("chef");
        }
      })
    });
  });
  //接收后厨完成订单
  socket.on("orderAccomplish",()=>{
    io.emit("orderOrderAccomplish");
  });
});
//用户扫码点餐路由
const Productsclass=require('./routers/productsclass')
// 后厨端路由
const Chef=require('./routers/chef')
// 后台管理路由
const Backstage=require('./routers/backstage');
app.listen(3000)
app.use(
  body.urlencoded({
    extended: false,
  })
);
app.use(express.static("upload"));
app.use(
  cors({
    origin: [
      "http://127.0.0.1:8080",
      "http://localhost:8080",
      "http://127.0.0.1:8081",
      "http://localhost:8081",
      "http://127.0.0.1:8082",
      "http://localhost:8082",
      "http://127.0.0.1:8083",
      "http://localhost:8083",
    ],
    credentials: true, // 允许客户端请求携带身份认证信息
  })
);
app.use("/", Productsclass);
app.use("/chef",Chef)
app.use("/backstage", Backstage);
// app.use( express.static(__dirname + "/uploads"));