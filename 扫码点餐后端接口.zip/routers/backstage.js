// 后台管理页面
const router = require("express").Router();
const pool = require("../pool");
const multer=require('multer')
const moment=require('moment')
const jwt=require('jsonwebtoken')
// const multer=require('multer')
// const upload = multer({ dest: __dirname + "../uploads" });



const funobj = function (rs) {
  let obj = {};
  if (rs[0]) {
    obj = {
      meta: {
        msg: "获取成功",
        status: 200,
      },
      data: rs,
    };
  } else {
    obj = {
      meta: {
        msg: "获取失败",
        status: 400,
      },
    };
  }
  return obj;
};

var timestamp = "";
var timepath = moment().format("YYYY-MM-DD");
var destination = "/upload/" + timepath;
var filename = "";

var storage = multer.diskStorage({
    //这里destination是一个字符串
    destination: '.' + destination,
    filename: function(req, file, cb) {
        //自定义设置文件的名字
        timestamp = new Date().getTime();
        let filenameArr = file.originalname.split('.');
        let mimetypename = filenameArr[filenameArr.length - 1];
        filename = 'upload-' + timestamp + '.' + mimetypename;
        cb(null, filename)
    }
});

var upload = multer({
  storage: storage,
});

router.get("/uploads", function (req, res, next) {
  res.render("upload");
});

router.post('/uploadImage', upload.single('file'), function(req, res, next) {
    imgname=req.file
    console.log(req.body);
    //拼接文件上传后的路径
    var url = destination + '/' + filename;
    res.send({
        code: true,
        msg: '上传成功',
        imageUrl: url
    })
});

// 获取所有用户账号
router.get('/alluser',(req,res)=>{
  let { pageSize, pageNum } = req.query;
  let num=(pageNum-1)*pageSize
  pool.query(`select * from useraccount`,(err,rs)=>{
    if(err) throw err;
    let total = rs.length;
    let arr=rs.splice(num,pageSize)
    let obj=funobj(arr)
    obj.total = total;
    res.send(obj)
  });


  // let { pageSize, pageNum } = req.query;
  // let num = (pageNum - 1) * pageSize;
  // let size = Number(pageSize);
  // let n=num+size
  // let sql = `select * from useraccount limit ?,?`;
  // pool.query(`select * from useraccount`,(er,result)=>{
  //   if(er) throw er;
  //   if (result.length<n){
  //     size = result.length - num;
  //   }
  //   if(size<0)return{meta:{msg:'获取失败',status:'400'}}
  //     pool.query(sql, [num, size], (err, rs) => {
  //       if (err) throw err;
  //       let obj = funobj(rs);
  //       obj.total=result.length
  //       res.send(obj);
  //     });
  // });
  
  
})
// 用户登录
router.post("/loginuser", (req, res) => {
  // console.log(req.params);
  let { username, userpwd } = req.body;
  let sql = `select * from useraccount where username=? and userpwd=?`;
  pool.query(sql, [username, userpwd], (err, rs) => {
    if (err) throw err;
    let obj = funobj(rs);
    const secret='GFRRestaurant'
    const token=jwt.sign({username:rs.username,userpwd:rs.userpwd},secret)
    obj.token=token
    res.send(obj);
  });
});
// 添加账号
router.post("/adduser", (req, res) => {
  let { username, userpwd, type, state } = req.body;
  let sql1 = `select * from useraccount where username=?`;
  pool.query(sql1, [username], (err, result) => {
    if (err) throw err;
    if (result[0]) {
      res.send({
        meta: {
          msg: "已有账号",
          status: 401,
        },
      });
      return;
    }
    let sql = `insert into useraccount values(null,?,?,?,?)`;
    pool.query(sql, [username, userpwd, type, state], (er, rs) => {
      if (er) throw er;
      let obj = {};
      if (rs.affectedRows === 1) {
        obj = {
          meta: {
            msg: "添加成功",
            status: 200,
          },
        };
      } else {
        obj = {
          meta: {
            msg: "添加失败",
            status: 400,
          },
        };
      }
      res.send(obj);
    });
  });
});
// 删除账号
router.delete('/deleteuser',(req,res)=>{
    let {id}=req.query;
    let sql = `delete from useraccount where id=?`;
    pool.query(sql,[id],(err,rs)=>{
        if(err) throw err;
        let obj={}
        if(rs.affectedRows===0){
            obj = {
              meta: {
                msg: "删除失败",
                status: 400
              },
            };
        }else{
            obj = {
              meta: {
                msg: "删除成功",
                status: 200,
              },
            };
        }
        res.send(obj)
    })
})
// 修改账号
router.put("/changeuser", (req, res) => {
  let { id, username, userpwd, type, state } = req.body;
  let sql = `update useraccount set username=?,userpwd=?,type=?,state=? where id=?`;
  pool.query(sql, [username, userpwd, type, state, id], (err, rs) => {
    if (err) throw err;
    let obj = {};
    if (rs.affectedRows === 0) {
      obj = {
        meta: {
          msg: "修改失败",
          status: 400,
        },
      };
    } else {
      obj = {
        meta: {
          msg: "修改成功",
          status: 200,
        },
      };
    }
    res.send(obj);
  });
});
// 修改账号类型
router.put('/changeusertype',(req,res)=>{
  let {type,id}=req.body
  let sql = `update useraccount set type=? where id=?`;
  pool.query(sql,[type,id],(err,rs)=>{
    if(err) throw err;
    if(rs.affectedRows===1){
      res.send({meta:{status:200,msg:'修改成功'}})
    }else{
      res.send({meta:{status:400},msg:'修改失败'})
    }
  })
})
// 获取所有食品
router.get('/gainmenu',(req,res)=>{
  let {pageSize,pageNum}=req.query
  let num = (pageNum - 1) * pageSize;
  let sql = `select * from productsdetails`;
  pool.query(sql,(err,rs)=>{
    if(err) throw err;
    let total = rs.length;
    rs.forEach(a => {
      a.taste = a.taste.split(";");
    });
    let arr = rs.splice(num, pageSize);
    let obj = funobj(arr);
    obj.total = total;
    res.send(obj)
  })
})
// 查找食品
router.get('/findfood',(req,res)=>{
    let {foodval}=req.query
    let sql = `select * from productsdetails where foodname like ?`;
    pool.query(sql, ["%" + foodval + "%"], (err, rs) => {
      if (err) throw err;
      let obj = funobj(rs);
      res.send(obj);
    });
})
// 删除食品
router.delete('/deletefood',(req,res)=>{
  let {id}=req.query
  let sql = `delete from productsdetails where id=?`;
  pool.query(sql,[id],(err,rs)=>{
    if(err) throw err;
    let obj = {};
    if (rs.affectedRows === 0) {
      obj = {
        meta: {
          msg: "删除失败",
          status: 400,
        },
      };
    } else {
      obj = {
        meta: {
          msg: "删除成功",
          status: 200,
        },
      };
    }
    res.send(obj)
  })
})
// 更改餐品类型
router.put('/changefoodtype',(req,res)=>{
  let {type,id}=req.body
  let sql = `update productsdetails set type=? where id=?`;
  pool.query(sql,[type,id],(err,rs)=>{
    if(err) throw err;
    if(rs.affectedRows===1){
      return res.send({ meta: { status: 200, msg: "修改成功" } });
    }else{
      return res.send({ meta: { status: 400, msg: "修改失败" } });
    }
  })
})

// 上传图片
// router.post('/uploads',(req,res)=>{
//   console.log(req.body);
// })
// 修改餐品
router.put('/editfood',(req,res)=>{
  let {id,foodname:n,price:p,type:t,imgurl:i,tasteStr:str}=req.body
  let sql= `update productsdetails set foodname=?,price=?,type=?,imgurl=?,taste=? where id=?`;
  pool.query(sql,[n,p,t,i,str,id],(err,rs)=>{
    if(err) throw err
    if(rs.affectedRows=1){
      res.send({meta:{status:200,msg:'修改成功'}})
    }else{
      res.send({ meta: { status: 400, msg: "修改失败" } });
    }
  })
})

// 获取所有套餐
router.get('/combo',(req,res)=>{
  let { pageSize, pageNum } = req.query;
  let num = (pageNum - 1) * pageSize;
  let sql = `select * from combo`;
  pool.query(sql, (err, rs) => {
    if (err) throw err;
    let total = rs.length;
    rs.forEach((item,v) => {
      let arr = item.content.split(";");
      rs[v].content = arr;
    });
    let arr = rs.splice(num, pageSize);
    let obj = funobj(arr);
    obj.total = total;
    res.send(obj);
  });
})
// 获取所有餐品名
router.get('/foodName',(req,res)=>{
  let sql = `select foodname from productsdetails`;
  pool.query(sql,(err,rs)=>{
    if(err) throw err;
    let arr=[]
    rs.forEach(e => {
      arr.push(e.foodname)
    });
    res.send(arr)
  })
})
// 插入新套餐
router.post('/addCombon',(req,res)=>{
  let {comboname,price,content}=req.body
  let sql=`insert into combo values(null,?,?,?,false)`
  pool.query(sql,[comboname,content,price],(err,rs)=>{
    if(err) throw err;
    if(res.affectedRows!==0){
      res.send({meta:{status:200},message:'添加成功'})
    }else{
      res.send({ meta: { status: 400 }, message: "添加失败" });
    }
  })
})
// 删除套餐
router.delete('/delCombo',(req,res)=>{
  let {id}=req.query
  let sql = `delete from combo where id=?`;
  pool.query(sql,[id],(err,rs)=>{
    if(err) throw err;
    if(rs.affectedRows===1){
      res.send({meta:{status:200,msg:'删除成功'}})
    }else{
      res.send({meta:{status:400,msg:'删除失败'}})
    }
  })
})
//修改套餐
router.put('/alterCombon',(req,res)=>{
  let {id,comboname,price,content}=req.body
  let sql = `update combo set comboname=?,content=?,price=? where id=?`;
  pool.query(sql, [comboname, content, price,id],(err,rs)=>{
    if(err) throw err;
    if(rs.affectedRows===1){
      res.send({meta:{status:200,msg:'修改成功'}})
    }else{
      res.send({meta:{status:400,msg:'修改失败'}})
    }
  });
})
// 修改套餐状态
router.put('/comboType',(req,res)=>{
  let {id,selltype}=req.body
  let sql=`update combo set selltype=${selltype} where id=?`
  pool.query(sql,[id],(err,rs)=>{
    if(err) throw err;
    if(rs.affectedRows===1){
      res.send({meta:{status:200,msg:'修改成功'}})
    }else{
      res.send({meta:{status:400,msg:'修改失败'}})
    }
  })
})

// 修改折扣
router.put("/editDiscPrice",(req,res)=>{
  let {id,discount,discprice}=req.body
  let sql = `update productsdetails set discount=?,discprice=? where id=?`;
  pool.query(sql, [discount, discprice,id],(err,rs)=>{
    if(err) throw err;
    if(rs.affectedRows===1){
      res.send({meta:{status:200,msg:'修改成功'}})
    }else{
      res.send({meta:{status:400,msg:'修改失败'}})
    }
  });
});

module.exports=router


