// 后厨端接口文档
const router = require("express").Router();
const pool = require("../pool");

const funobj = function (rs) {
  let obj = {};
  if (rs[0]) {
    obj = {
      meta: {
        msg: "获取成功",
        status: 200,
      },
      data: rs,
    };
  } else {
    obj = {
      meta: {
        msg: "获取失败",
        status: 400,
      },
    };
  }
  return obj;
};
// 获取所有未完成状态的订单
router.get('/allChef',(req,res)=>{
    let sql = `select * from productsorder where state!=2`;
    pool.query(sql,(err,rs)=>{
        if(err) throw err;
        let obj=funobj(rs)
        res.send(obj)
    })
})
// 更改订单状态
router.put("/changeState",(req,res)=>{
    let oj=req.body
    let sql = `update productsorder set state=?,chefname=? where id=?`;
    let proSql = `update productsdetails set ordernum=? where foodname=?`;
    let proSel = `select ordernum from productsdetails where foodname=?`;
    // 修改订单状态
    pool.query(sql,[oj.state,oj.chefname,oj.id],(err,rs)=>{
        if(err) throw err;
        if(rs.affectedRows==1){
            res.send({
                mate:{
                    msg:'更改成功',
                    status:200
                }
            })
        }
    })
    if(oj.state==='2' && oj.orderNum!==undefined){
      // 修改购买餐品数量
      pool.query(proSel, [oj.foodname], (err, rs) => {
        if (err) return err;
        console.log(rs);
        let orderNum = rs[0].ordernum + 1;
        pool.query(proSql,[orderNum,oj.foodname],er=>{
          if(er) throw er;
          console.log('cheng');
        });
      });
    }
});
// 后厨端 登录接口
router.post('/login',(req,res)=>{
    let oj=req.body
    let sql = `select * from useraccount where username=? and userpwd=?`;
    pool.query(sql,[oj.username,oj.userpwd],(err,rs)=>{
        if(err) throw err;
        let obj=funobj(rs)
        res.send(obj)
    })
})

module.exports=router