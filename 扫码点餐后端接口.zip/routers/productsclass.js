//用户点餐页
const router=require('express').Router()
const pool=require('../pool')
const funobj = function (rs) {
  let obj = {};
  if (rs[0]) {
    obj = {
      meta: {
        msg: "获取成功",
        status: 200,
      },
      data: rs,
    };
  } else {
    obj = {
      meta: {
        msg: "获取失败",
        status: 400,
      },
    };
  }
  return obj;
};
//获取餐类型
router.get('/foodclass',(req,res)=>{
    let sql = `select * from productsclass`;
    pool.query(sql,(err,rs)=>{
        if(err) throw err;
        let obj=funobj(rs)
        res.send(obj);
    })
})
//获取所有或对应的饭的详情
router.get('/food',(req,res)=>{
    let foodtype=req.query.foodtype
    let sql = `select * from productsdetails`;
    if (foodtype !== "0") {
        sql+=` where type=?`
    }
    pool.query(sql,[foodtype],(err,rs)=>{
        if(err) throw err;
        let obj = funobj(rs)
        res.send(obj)
    })
})
//获取当前座位是否有订单
router.get('/isorder',(req,res)=>{
    let seatnum=req.query.seatnum
    let sql = `select * from productsorder where seatnum=? and state!=2`;
    pool.query(sql, [seatnum], (err, rs) => {
      if (err) throw err;
      let obj = funobj(rs);
      res.send(obj);
    });
})
//用户下单存入订单
router.post('/deposit',(req,res)=>{
    let dp=req.body
    let sql = `insert into productsorder values(null,?,?,?,?,?,?,null)`;
    if (!dp.taste) {
      dp.taste = null;
    }
    pool.query(sql, [dp.seatnum,dp.footname,dp.state,dp.taste,dp.time,dp.price], (err, rs) => {
      if (err) throw err;
      let obj={}
      if(rs.affectedRows===1){
          obj = {
                    meta: {
                        msg: "添加成功",
                        status: 200
                    }
                };
      }else{
          obj={
              mets:{
                  msg:'添加失败',
                  status:400
              }
          }
      }
      res.send(obj)
    });
    
})
// 通过餐名字查找餐品
router.get('/foodname',(req,res)=>{
  let id=req.query.id
  let sql = `select * from productsorder where id=?`;
  pool.query(sql, [id], (err, rs) => {
    if (err) throw err;
    res.send(rs)
  });
})
// 获取轮播图图片数据
router.get('/imglist',(req,res)=>{
  let num = Math.round(Math.random() * 21);
  let sql = `select imgurl from productsdetails where type!=11 limit ?,5`;
  pool.query(sql,[num],(err,rs)=>{
    if(err) throw err;
    res.send(funobj(rs))
  })
})
// 获取套餐
router.get("/comboMeal",(req,res)=>{
  let sql=`select * from combo where selltype!=0`
  let imgSql = `select imgurl from productsdetails where foodname=?`;
  pool.query(sql,(err,rs)=>{
    if(err) throw err;
    rs.forEach((e,v) => {
      pool.query(imgSql, [e.content.split(";")[0]],(er,re)=>{
        if(er) throw er;
        rs[v].imgurl = re[0].imgurl;
        if(rs.length-1===v){
          res.send(rs)
        }
      });
    });
  })
});
// 获取销量榜
router.get('/salesFood',(req,res)=>{
  let sql = `SELECT * FROM productsdetails ORDER BY ordernum DESC LIMIT 0,5`;
  pool.query(sql,(err,rs)=>{
    if(err) throw err;
    res.send(rs)
  })
})
module.exports=router